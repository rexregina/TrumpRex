/**
 * Trump Rex Home Page - Simplified
 * Design: Retro Propaganda Poster Aesthetic
 * 
 * Minimal layout: Banner + Framed Photo only
 */

import { Crown } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground paper-texture flex flex-col">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b-2 border-foreground shadow-md">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Crown className="w-8 h-8 text-primary" />
            <h1 className="text-2xl font-bold font-display text-primary">TRUMP REX</h1>
          </div>
        </div>
      </header>

      {/* Main Content - Centered Photo */}
      <main className="flex-1 flex items-center justify-center py-12 md:py-20 px-4">
        <div className="distressed-border p-6 md:p-8 bg-background hover-scale max-w-2xl w-full">
          <img 
            src="/trumprex-hero.jpg" 
            alt="Trump Rex - The Burger King Supreme" 
            className="w-full h-auto object-cover"
          />
        </div>
      </main>
    </div>
  );
}
